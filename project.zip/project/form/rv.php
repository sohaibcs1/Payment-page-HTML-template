<!DOCTYPE html>
<html>
<link rel="stylesheet" href="form.css" >
<head>
	<title>
		Reviews
	</title>
	</head>
	<body align="center">
	<div class="col-md-6 col-md-offset-4" id="form_container">
                    <h2>Customer Reviews</h2> 
</div>
<?php include('view.php');?>

<style>
.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 14px 33px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 15px;
  margin: 4px 3px;
  cursor: pointer;
}
</style>
<button class="button" onclick="document.location='../index.html'">BACK</button>
</body>
</html>